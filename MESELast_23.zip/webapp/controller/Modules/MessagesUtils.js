sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/ValueState",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/Button",
	"sap/m/ButtonType",
	"sap/m/Text",
	"sap/m/MessageBox"
], function(JSONModel, ValueState, Dialog, DialogType, Button, ButtonType, Text, MessageBox) {
	var oMsgModule = {
		createMsgPopOver: function(aMsgs) {

			var oLink = new sap.m.Link({
				text: "Show more information",
				//href: "http://sap.com",
				target: "_blank"
			});
			var that = this;
			var oMessageTemplate = new sap.m.MessageItem({
				type: "{type}",
				title: "{title}",
				description: "{description}",
				subtitle: "{subtitle}",
				counter: "{counter}",
				markupDescription: "{markupDescription}",
				link: oLink
			});
			var oBackButton = new Button({
				icon: "sap-icon://nav-back",
				visible: false,
				press: function() {
					that.oMessageView.navigateBack();
					this.setVisible(false);
				}
			});

			var oModel = new JSONModel(aMsgs);

			this.oMessageView = new sap.m.MessageView({
				showDetailsPageHeader: false,
				itemSelect: function() {
					oBackButton.setVisible(true);
				},
				items: {
					path: "/",
					template: oMessageTemplate
				}
			});
			this.oMessageView.setModel(oModel);
			var sDialogState = "Success"
			var bThereIsErrorMsg = aMsgs.findIndex(oMsg => oMsg.type === "Error") > -1;
			if (bThereIsErrorMsg) {
				sDialogState = "Error"
			} else {
				var bThereIsWarningMsg = aMsgs.findIndex(oMsg => oMsg.type === "Warning") > -1;
				if (bThereIsWarningMsg) {
					sDialogState = "Warning"
				} else {
					var bThereIsInfoMsg = aMsgs.findIndex(oMsg => oMsg.type === "Information") > -1;
					if (bThereIsInfoMsg) {
						sDialogState = "Info"
					}
				}
			}
			this.oImmoMsgDialog = new sap.m.Dialog({
				resizable: true,
				content: this.oMessageView,
				state: sDialogState,
				beginButton: new sap.m.Button({
					press: function() {
						this.getParent().close();
					},
					text: "Femer"
				}),
				customHeader: new sap.m.Bar({
					contentLeft: [oBackButton],
					contentMiddle: [
						new sap.m.Title({
							text: "Retour Immobilisation"
						})
					]
				}),
				contentHeight: "50%",
				contentWidth: "50%",
				verticalScrolling: false
			});
			this.oImmoMsgDialog.open();

		}
	};

	return oMsgModule;
});