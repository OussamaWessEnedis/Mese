sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/ValueState",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/Button",
	"sap/m/ButtonType",
	"sap/m/Text",
	"sap/m/MessageBox"
], function(JSONModel, ValueState, Dialog, DialogType, Button, ButtonType, Text, MessageBox) {
	var UserHeaderActionModule = {
		onMeseValidateHandler: function(oEvent) {
			var that = this;
			var oBusyDialog = new sap.m.BusyDialog();
			oBusyDialog.open();
			this.UserHedarActionsModule.onUserAction.apply(this, ["Validate"]).then(oResp => {
				oBusyDialog.close();
				that.UserHedarActionsModule.showReturnMsgs.apply(that, [oResp]);
			}).catch(oResp => {
				oBusyDialog.close();
			});
		},
		onMeseSimulateHandler: function(oEvent) {
			var that = this;
			var oBusyDialog = new sap.m.BusyDialog();
			oBusyDialog.open();
			this.UserHedarActionsModule.onUserAction.apply(this, ["Simulate"]).then(oResp => {
				oBusyDialog.close();
				that.UserHedarActionsModule.showDocument.apply(that, [oResp]);
			}).catch(oResp => {
				oBusyDialog.close();
			});
		},
		showDocument: function(oActionResp) {
			var aMsgs = this.UserHedarActionsModule.getImmoReturnMsgs.apply(this, [oActionResp]);
			var bThereIsErrorMsg = aMsgs.findIndex(oMsg => oMsg.type === "Error") > -1;
			if (bThereIsErrorMsg) {
				this.MessagesModule.createMsgPopOver.apply(this, [aMsgs]);
			} else {
				var objectId = "0001"; //oItem.getBindingContext().getProperty("Posid")
				this.getRouter().navTo("object", {
					objectId: objectId
				});
			}

		},
		onMeseControlHandler: function(oEvent) {
			var that = this;
			var oBusyDialog = new sap.m.BusyDialog();
			oBusyDialog.open();
			this.UserHedarActionsModule.onUserAction.apply(this, ["Control"]).then(oResp => {
				//var aBapiReturns = JSON.parse(oResp.headers["sap-message"]).details;
				oBusyDialog.close();
				that.UserHedarActionsModule.showReturnMsgs.apply(this, [oResp]);
			}).catch(oResp => {
				oBusyDialog.close();
			});
		},
		onUserAction: function(sAction) {
			var oMainService = this.getOwnerComponent().getModel(),
				sParamsPaylod = this.UserHedarActionsModule.prepareMeseCtrlPayload.apply(this);
			return new Promise(function(resolve, reject) {
				oMainService.callFunction("/controlMese", {
					method: "GET",
					urlParameters: {
						"MESE": sParamsPaylod,
						"Action": sAction
					},
					success: function(oSuccess, oResp) {
						resolve(oResp);
					},
					error: oResp => reject(oResp)
				});
			});
		},
		prepareMeseCtrlPayload: function() {
			var oMese = this.prepareMeseData();
			var oMyPayload = {
				Pbukr: oMese.Pbukr,
				Pkokr: oMese.Pkokr,
				PsPspnr: oMese.PsPspnr,
				YaaNbreMese: oMese.YaaNbreMese
			};
			return JSON.stringify(oMyPayload);
			var oMese = this.prepareMeseData();
		
		},
		showReturnMsgs: function(oActionResp) {
			var aMsgs = this.UserHedarActionsModule.getImmoReturnMsgs.apply(this, [oActionResp]);
			this.MessagesModule.createMsgPopOver.apply(this, [aMsgs]);
		},
		getImmoReturnMsgs: function(oActionResp) {
			var aMsgs = [];
			var oHeaderMsg = JSON.parse(oActionResp.headers["sap-message"]),
				aHeaderMsgDetailsMsgs = oHeaderMsg.details;

			aMsgs.push(this.UserHedarActionsModule.formatMsgAttributs.apply(this, [oHeaderMsg]));
			aHeaderMsgDetailsMsgs.forEach(oHeaderMsgDetails => {
				aMsgs.push(this.UserHedarActionsModule.formatMsgAttributs.apply(this, [oHeaderMsgDetails]));
			});
			return aMsgs;
		},
		formatMsgAttributs: function(oRespMsg) {
			var oReturnMsg = {};
			/*Type*/
			if (oRespMsg.severity === "error") {
				oReturnMsg.type = "Error"
			}
			if (oRespMsg.severity === "success") {
				oReturnMsg.type = "Success"
			}
			if (oRespMsg.severity === "warning") {
				oReturnMsg.type = "Warning"
			}
			if (oRespMsg.severity === "information") {
				oReturnMsg.type = "Information"
			}
			oReturnMsg.title = oRespMsg.message;
			oReturnMsg.description = oRespMsg.code;
			return oReturnMsg;
		}
	};

	return UserHeaderActionModule;
});