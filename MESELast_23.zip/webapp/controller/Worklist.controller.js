/*global location history */
sap.ui.define([
	"enedis/fiaa/mese/MESE_NEW/model/models",
	"enedis/fiaa/mese/MESE_NEW/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"enedis/fiaa/mese/MESE_NEW/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	'sap/m/MessageItem',
	'sap/ui/core/Element',
	"./Modules/MessagesUtils",
	"./Modules/UserHeaderAction"
], function(Models, BaseController, JSONModel, formatter, Filter, FilterOperator, MessageItem, Element, MessagesUtils, UserHeaderAction) {
	"use strict";

	return BaseController.extend("enedis.fiaa.mese.MESE_NEW.controller.Worklist", {

		formatter: formatter,
		MessagesModule: MessagesUtils,
		UserHedarActionsModule: UserHeaderAction,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			var oViewModel,
				// Model used to manipulate control states
				oViewModel = new JSONModel({
					tableBusyDelay: 0
				});
			this.setModel(oViewModel, "createMeseModel");

			var oViewModel1 = new JSONModel({
				tableBusyDelay: 0
			});
			this.setModel(oViewModel, "createMeseModel");
			//this.setModel(oViewModel1, "MeseItemsJSON");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("worklist").attachPatternMatched(this.onObjectMatched, this);

			var oMessageManager;
			oMessageManager = sap.ui.getCore().getMessageManager();
			this.getView().setModel(oMessageManager.getMessageModel(), "message");
			oMessageManager.registerObject(this.getView(), true);

			this.initVhModels();

		},
		initVhModels: function() {
			/*Init VhEti Model*/
			var oEtiVhModel = new JSONModel();
			this.getView().setModel(oEtiVhModel, "EtiVh");
			/*Init VHCommune Model*/
			var oCommuneVhModel = new JSONModel();
			this.getView().setModel(oCommuneVhModel, "communeVh");
		},
		fetchVhDataToModels: function() {
			var that = this;
			/*Initialising Vh*/
			this.getVh("/EtiVhSet").then(oSuccess => {
				that.getView().getModel("EtiVh").setData(oSuccess);
			});
			this.getVh("/InseeVhSet").then(oSuccess => {
				that.getView().getModel("communeVh").setData(oSuccess);
			});
		},

		onObjectMatched: function(oEvent) {
			var that = this;
			this.initialDataLoading(oEvent);
			this.fetchVhDataToModels();
		},

		initialDataLoading: function(oEvent) {

			//get navigation params
			var that = this;
			if (this.getOwnerComponent().getComponentData()) {
				var argumentsParam = this.getOwnerComponent().getComponentData().startupParameters

				var Pbukr = decodeURI(argumentsParam.Pbukr[0]),
					Pkokr = decodeURI(argumentsParam.Pkokr[0]),
					WBSElement = decodeURI(argumentsParam.WBSElement[0]);

				//var hash = sap.ui.core.routing.HashChanger.getInstance().getCurrentNavigationState().newHash.split("?")[1].split("&");
				// var Pbukr = hash[0].split("=")[1];
				// var Pkokr = hash[1].split("=")[1];
				// var WBSElement = hash[2].split("=")[1];

			} else {
				var Pbukr = "D001";
				var Pkokr = "EH00";
				var WBSElement = "PR00000281";
			}
			var oBusyDialog = new sap.m.BusyDialog();
			oBusyDialog.open();
			this.initHeader(Pbukr, Pkokr, WBSElement).then(oSuccess => {
				that.populateNavMeseModel(oSuccess);
				that.getHeaderData(oSuccess, oBusyDialog);
				//that._getBackValueForGeneralDataControl();

			});
			this.onInitiliseMeseRepartParam(Pkokr, WBSElement);
			this.setMaxMeseDate();

		},

		initHeader: function(Pbukr, Pkokr, WBSElement) {
			var oMainService = this.getOwnerComponent().getModel();

			return new Promise(function(resolve, reject) {
				oMainService.callFunction("/initHeader", {
					method: "GET",
					urlParameters: {
						"Societe": Pbukr,
						"Perimetre": Pkokr,
						"WBSElement": WBSElement
					},
					success: function(oSuccess, oResp) {
						resolve(oSuccess);
					},
					error: oResp => reject(oResp)
				});
			});
		},

		populateNavMeseModel: function(data) {

			this.getOwnerComponent().getModel("createMeseNavModel").setData(data);

		},

		getHeaderData: function(data, busyDialog) {
			var that = this;
			var path = "/MeseHeaderSet(Draftuuid='" + data.Draftuuid + "',IsActive='',YaaNbreMese='" + data.YaaNbreMese + "',Pbukr='" + data.Pbukr +
				"',Pkokr='" + data.Pkokr + "',PsPspnr='" + data.PsPspnr + "')";
			this.getView().getModel().read(path, {
				success: function(data, resp) {

					that.onPrepareMeseData(data);
					that.onHeaderDataChange();
					busyDialog.close();
				}.bind(this),
				error: function(err) {
					busyDialog.close();
				}

			});
		},

		onChangeEti: function(e) {
			this.onHeaderDataChange();
			this.checkETI();
		},

		checkETI: function(e) {
			this.updateEti().then(function() {
				//this.changeDefaultValueAfterETIChange();
			}.bind(this));
		},

		onCheckTypeRepartition: function(oEvent) {
			var typeRepartValue = oEvent.getSource().getValue();
			var selectedKey = oEvent.getSource().getSelectedKey();
			this.getView().getModel("createMeseModel").setProperty("/YyaatypeRepart", selectedKey);
			this.getView().rerender();
			/*		var oValueModel = this.getModel("fieldsStateGeneralDataModel");
					if (typeRepartValue === "") {
						oValueModel.setProperty(
							"/typeRepartComboId/valueStateText",
							"Champ obligatoire"
						);
						oValueModel.setProperty("/typeRepartComboId/valueState", "Error");
					} else {
						oValueModel.setProperty("/typeRepartComboId/valueStateText", "");
						oValueModel.setProperty("/typeRepartComboId/valueState", "None");
					}

					var oModel = this.getModel("meseCreationModel");
					var oModelData = oModel.getData();
					oModelData.YyaatypeRepart = oEvent.getSource().getSelectedKey();
					oModelData.YyaatypeRepartTxt = oEvent.getSource().getSelectedItem().getText();
					oModel.setData(oModelData);
					oModel.refresh();

					this.changeDefaultValueRegRepart(oEvent.getSource().getSelectedKey());*/
		},

		onCheckDateValidity: function(oEvent) {
			var oSelectedDate = oEvent.getSource().getValue();
			this.getView().getModel("createMeseModel").setProperty("/YyaadateMese", oSelectedDate);
			this.checkMeseDate(oSelectedDate);
			this.onHeaderDataChange();
			/*	var oValueModel = this.getModel("fieldsStateGeneralDataModel");
				var oSelectedDate = oEvent.getSource().getDateValue();
				if (oSelectedDate) {
					oValueModel.setProperty("/dateMeseInputId/valueState", "None");
					oValueModel.setProperty("/dateMeseInputId/valueStateText", "");
					var oTodayDate = new Date(Date.now());
					if (oSelectedDate.getFullYear() > oTodayDate.getFullYear()) {
						if (!this._ViewGeneralDataError) {
							this._ViewGeneralDataError = this._instantiateFragment(
								"enedis.fiaa.mese.MESE_NEW.view.fragments.ViewGeneralDataErrorMsgDialog"
							);
							this.getView().addDependent(this._ViewGeneralDataError, this);
						}
						this.getView()
							.getModel("errorMsgPopupModel")
							.setProperty(
								"/text",
								"Message d'erreur 006 : Une mise en service sur un exercice comptable non ouvert n’est pas autorisée "
							);
						this._ViewGeneralDataError.open();
						oValueModel.setProperty("/dateMeseInputId/valueState", "Error");
					} else if (oSelectedDate.getFullYear() < oTodayDate.getFullYear()) {
						if (!this._ViewGeneralDataError) {
							this._ViewGeneralDataError = this._instantiateFragment(
								"enedis.fiaa.mese.MESE_NEW.view.fragments.ViewGeneralDataErrorMsgDialog"
							);
							this.getView().addDependent(this._ViewGeneralDataError, this);
						}
						this.getView()
							.getModel("errorMsgPopupModel")
							.setProperty(
								"/text",
								"Message d'erreur 007: La date saisie est dans un exercice comptable clôturé"
							);
						this._ViewGeneralDataError.open();
						oValueModel.setProperty("/dateMeseInputId/valueState", "Error");
					} else {
						if (oValueModel.getProperty("/etiInputId/backEditable")) {
							oValueModel.setProperty("/etiInputId/editable", true);
						}
					}
				} else {
					oValueModel.setProperty("/dateMeseInputId/valueState", "Error");
					oValueModel.setProperty(
						"/dateMeseInputId/valueStateText",
						"Champ obligatoire"
					);
					oValueModel.setProperty("/etiInputId/editable", false);
				}*/
		},

		onValueHelpRequest: function(oEvent) {
			var sId = oEvent.getSource().getId();
			var sdateMese = this.byId("dateMeseInputId").getDateValue();
			var oVhDialogConfig = this._initVhDialogConfig(sId);
			this.oColModel = new JSONModel(oVhDialogConfig.columnsConfig);
			var aCols = this.oColModel.getData().cols;
			new sap.ui.core.Fragment.load({
				name: "enedis.fiaa.mese.MESE_NEW.view.fragments." + oVhDialogConfig.fragmentName,
				controller: this,
			}).then(
				function name(oFragment) {
					this._oValueHelpDialog = oFragment;
					this.getView().addDependent(this._oValueHelpDialog);
					this._oValueHelpDialog.getTableAsync().then(
						function(oTable) {
							oTable.setModel(this.oColModel, "columns");
							if (oTable.bindRows) {
								oTable.bindAggregation("rows", oVhDialogConfig.entitySet);
							}
							if (oTable.bindItems) {
								oTable.bindItems({
									path: oVhDialogConfig.entitySet,
									urlParameters: {
										param1: sdateMese,
									},
									events: {
										// dataReceived: this.onDataReceived.bind(this),
										dataReceived: ".onDataReceived",
									},
									factory: function() {
										return new sap.m.ColumnListItem({
											cells: aCols.map(function(column) {
												return new sap.m.Label({
													text: "{" + column.template + "}",
												});
											}),
										});
									},
								});
							}
							this.byId(sId).bindAggregation("suggestionItems", {
								path: oVhDialogConfig.entitySet,
								factory: function() {
									return new sap.ui.core.Item({
										key: "{" + aCols[0].template + "}",
										text: "{" + aCols[0].template + "}", // ({" + aCols[1].template + "})",
									});
								},
							});
							this._oValueHelpDialog.update();
						}.bind(this)
					);
					this._oValueHelpDialog.open();
				}.bind(this)
			);
		},

		onValueHelpOkPress: function(oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			if (aTokens.length > 0) {
				this._oInput.setSelectedKey(aTokens[0].getKey());
				// if (this._oInput === this.byId("motifRetInputId")) {
				// 	this.getModel("fieldsStateGeneralDataModel").setProperty(
				// 		"/motifRetInputId/valueState",
				// 		"None"
				// 	);
				// 	this.getModel("fieldsStateGeneralDataModel").setProperty(
				// 		"/motifRetInputId/valueStateText",
				// 		""
				// 	);
				// }
			}
			this.onHeaderDataChange();
			this._oValueHelpDialog.close();
		},

		onValueHelpCancelPress: function() {
			this._oValueHelpDialog.close();
		},

		onValueHelpAfterClose: function() {
			this._oValueHelpDialog.destroy();
		},

		onDataReceived: function() {
			//           console.log("Data received");
		},

		_getBackValueForGeneralDataControl: function() {
			var oBusyDialog = new sap.m.BusyDialog();
			oBusyDialog.open();
			this.getOwnerComponent()
				.getModel()
				.callFunction("/controlUi5DataField", {
					urlParameters: {
						I_OBJNR: this.getOwnerComponent()
							.getModel("createMeseNavModel")
							.getProperty("/Objnr"),
						I_PBUKR: this.getOwnerComponent()
							.getModel("createMeseNavModel")
							.getProperty("/Pbukr"),
						I_YYPINS: this.getOwnerComponent()
							.getModel("createMeseNavModel")
							.getProperty("/YyaainsI"),
						I_YYPSETI: this.getOwnerComponent()
							.getModel("createMeseNavModel")
							.getProperty("/YyaaetiI"),
					},
					success: function(data, resp) {
						if (resp.headers["sap-message"]) {
							var oResponse = $.parseJSON(resp.headers["sap-message"]);
							if (oResponse.severity !== "success") {
								var message = $.parseJSON(
									resp.headers["sap-message"]
								).message;
								sap.m.MessageBox.warning(message);
								oBusyDialog.close();
								return;
							}
						}
						this._setDefaultGeneralDataValues(data.controlUi5DataField);
						//set the Type de répartition model
						this.getView().setModel(
							Models.fieldsStateGeneralDataModel(
								data.controlUi5DataField,
								this
							),
							"fieldsStateGeneralDataModel"
						);
						oBusyDialog.close();
					}.bind(this),
					error: function(data, resp) {
						oBusyDialog.close();
					},
				});
		},

		_initVhDialogConfig: function(sId) {
			var sFragmentName;
			var oData;
			var sEntitySet;
			switch (sId) {
				case this.byId("etiInputId").getId():
					this._oInput = this.getView().byId("etiInputId");
					sFragmentName = "ValueHelpEti";
					sEntitySet = "/EtiVhSet";
					oData = {
						cols: [{
							label: "Code Eti",
							template: "Eti",
							width: "5rem",
						}, {
							label: "Libelle",
							template: "Libelle"
						}, {
							label: "Famille",
							template: "Famille"
						}, ],
					};
					break;
				case this.byId("inseeInputId").getId():
					this._oInput = this.getView().byId("inseeInputId");
					sFragmentName = "ValueHelpCommune";
					sEntitySet = "/InseeVhSet";
					oData = {
						cols: [{
							label: "Code Insee",
							template: "Commune",
							width: "5rem",
						}, {
							label: "Libelle",
							template: "Libelle"
						}, {
							label: "Département",
							template: "Departement",
						}, ],
					};
					break;
				case this.byId("motifRetInputId").getId():
					this._oInput = this.getView().byId("motifRetInputId");
					sFragmentName = "ValueHelpMotifRetard";
					sEntitySet = "/MotifRetVhSet";
					oData = {
						cols: [{
							label: "Code Motif Retard",
							template: "MotifRetard",
							width: "5rem",
						}, {
							label: "Libelle",
							template: "Libelle"
						}, ],
					};
					break;
				default:
			}
			return {
				fragmentName: sFragmentName,
				entitySet: sEntitySet,
				columnsConfig: oData,
			};
		},

		_setDefaultGeneralDataValues: function(oData) {
			var oTypeRepartComboIdModel = this.getOwnerComponent().getModel("typeRepartComboIdModel").getData();
			var idx = this.getOwnerComponent().getModel("meseCreationModel").getProperty("/YyaatypeRepart") - 1;
			this.getOwnerComponent()
				.getModel("meseCreationModel")
				.setProperty("/YyaatypeRepart", "1");

			this.getOwnerComponent()
				.getModel("meseCreationModel")
				.setProperty(
					"/YyaatypeRepartTxt",
					oTypeRepartComboIdModel.types[idx].text
				);

			this.getOwnerComponent()
				.getModel("meseCreationModel")
				.setProperty(
					"/YyaaetiF",
					this.getOwnerComponent()
					.getModel("createMeseNavModel")
					.getProperty("/YyaaetiI")
				);

			this.getOwnerComponent()
				.getModel("meseCreationModel")
				.setProperty(
					"/YyaainsF",
					this.getOwnerComponent()
					.getModel("createMeseNavModel")
					.getProperty("/YyaainsI")
				);

			this.getOwnerComponent()
				.getModel("meseCreationModel")
				.setProperty(
					"/YyaaTextF",
					this.getOwnerComponent()
					.getModel("createMeseNavModel")
					.getProperty("/YyaaTextI")
				);

			this.getOwnerComponent()
				.getModel("meseCreationModel")
				.setProperty("/YaanbrjRet", "25");

			if (oData.Libelle) {
				this.getOwnerComponent()
					.getModel("meseCreationModel")
					.setProperty("/YyaaTextF", oData.Libelle);
			}
		},

		// A affiner avec l'header + navigation après fusion des codes
		updateEti: function(e) {
			var sEti = this.getModel("meseCreationModel").getData().Ypseti || this.getModel("createMeseNavModel").getData().YyaaetiF;
			var sPath = "/EtiSet(Ypseti='" + sEti + "')";
			return new Promise(function(r, R) {
				this.getView().getModel().read(sPath, {
					success: function(e) {
						//Transformer l'oData en JSON simple, sans les attributs d'objet si odata direct et sans uri etc si passage du result
						delete e.__metadata;
						var oODataJSONModel = new JSONModel();
						oODataJSONModel.setData(e);
						this.setModel(oODataJSONModel, "EtiSet");
						this.changeDefaultValueAfterETIChange();
						//return Promise.resolve();
					}.bind(this),
					error: function(e) {
						//return Promise.resolve();
					}
				}, this);
			}.bind(this));
		},

		changeDefaultValueAfterETIChange: function(nTypRepart) {
			//var oMeseCreationModel = this.getView().getModel("meseCreationModel");
			//oMeseCreationModel.refresh();
			//var oTab = this.byId(sap.ui.core.Fragment.createId("RegRepartFragment", "table-Reg-Repart"));

			//for (var i = 0; i < oModelData.length; i++) {
			//oModelData[i]
			//}
			//oModel.setProperty("/MeseItems", oModelData);
		},

		changeDefaultValueRegRepart: function(nTypRepart) {
			/*		var oModel = this.getView().getModel("MeseItemsJSON");
					//var oModel = this.getView().getModel("MeseItemsSet");
					var oModelData = oModel.getProperty("/");
					var oMeseCreationModel = this.getView().getModel("meseCreationModel").getData();

					for (var i = 0; i < oModelData.length; i++) {
						if (oMeseCreationModel.YyaatypeRepart === "1") {
							oModelData[i].YyaaPourcent = 100;
						}
					}
					oModel.setProperty("/MeseItems", oModelData);*/
		},

		onAddMeseItems: function(e) {

			var oTable = this.getView().byId("tableSmart-Desc-Comp");
			//Ajouter un call fonction pour checker le MESE - 1
			/*
			                             var oBusyDialog = new sap.m.BusyDialog();
			                                           oBusyDialog.open();
			                                           this.getOwnerComponent()
			                                                         .getModel()
			                                                         .callFunction("/getMeseNless1", {
			                                                                       urlParameters: {
			                                                                                     I_PSPNR: this.getOwnerComponent()
			                                                                                                   .getModel("createMeseNavModel")
			                                                                                                   .getProperty("/PsPspnr"),
			                                                                                     I_PKOKR: this.getOwnerComponent()
			                                                                                                   .getModel("createMeseNavModel")
			                                                                                                   .getProperty("/Pkokr"),
			                                                                                     I_PBUKR: this.getOwnerComponent()
			                                                                                                   .getModel("createMeseNavModel")
			                                                                                                   .getProperty("/Pbukr"),
			                                                                       },
			                                                                       success: function(data, resp) {
			                                                                                     if (resp.headers["sap-message"]) {
			                                                                                                   var oResponse = $.parseJSON(resp.headers["sap-message"]);
			                                                                                                   if (oResponse.severity !== "success") {
			                                                                                                                  var message = $.parseJSON(
			                                                                                                                                resp.headers["sap-message"]
			                                                                                                                  ).message;
			                                                                                                                  sap.m.MessageBox.warning(message);
			                                                                                                                  oBusyDialog.close();
			                                                                                                                  return;
			                                                                                                   }
			                                                                                     }
			                                                                                     oBusyDialog.close();
			                                                                                     //set the Type de répartition model
			                                                                                     this.getView().setModel(
			                                                                                     );
			                                                                       }.bind(this),
			                                                                       error: function(data, resp) {
			                                                                                     oBusyDialog.close();
			                                                                       },
			                                                         });*/
			var oActions = [];
			var oModel = this.getView().getModel("MeseItemsJSON");
			if (oModel.getData().length) {
				oActions = oModel.getData();
			}
			var oDefaultRepart = {};
			var oDefaultHeader = this.prepareMeseData();
			var oDefaulNavtHeader = this.getView().getModel("createMeseNavModel").getData();
			//	var oEtiSet = this.getView().getModel("EtiSet").getData();
			if (this.getView().getModel("RepartImmSet")) {
				var oRepartImmSet = this.getView().getModel("RepartImmSet").getData();
			} else {
				oRepartImmSet = new Models.createRepartImmModel().getData();
			}

			//Ajouter les valeurs de l'header
			oDefaultRepart.Pkokr = oDefaultHeader.Pkokr;
			oDefaultRepart.PsPspnr = oDefaultHeader.PsPspnr;
			oDefaultRepart.Pbukr = oDefaultHeader.Pbukr;
			oDefaultRepart.YaaNbreMese = oDefaultHeader.YaaNbreMese;
			oDefaultRepart.YyaaUQte = oDefaultHeader.Yypseti;
			oDefaultRepart.YyaaetiF = oDefaultHeader.YyaaetiF;
			oDefaultRepart.YyaainsF = oDefaultHeader.YyaainsF;
			oDefaultRepart.YyaaTextF = oDefaultHeader.YyaaTextF;
			oDefaultRepart.YyaaErspe = this.getOwnerComponent().getModel("MeseRepartParam").getProperty("/Yperiode_val_deb");
			oDefaultRepart.YyaaErsja = this.getOwnerComponent().getModel("MeseRepartParam").getProperty("/Yperiode_val_fin");
			oDefaultRepart.YyaaLetpe = this.getOwnerComponent().getModel("MeseRepartParam").getProperty("/Yexercice_val_deb");
			oDefaultRepart.YyaaLetja = this.getOwnerComponent().getModel("MeseRepartParam").getProperty("/Yexercice_val_fin");

			if (oDefaultHeader.YyaatypeRepart === "1" || oDefaultHeader.YyaatypeRepart === "2") {
				oDefaultRepart.YyaaPourcent = "100";
			}
			if (oDefaultHeader.YyaatypeRepart === "3") {
				oDefaultRepart.YyaaCoeff = "1";
				oDefaultRepart.YyaaDev = this.getOwnerComponent().getModel("MeseRepartParam").getProperty("/YDevise");

			}

			// if (oDefaulNavtHeader.YpsetiMuli === "") {
			// 	oDefaultRepart.YyaaErsja = oRepartImmSet.Ersja;
			// 	oDefaultRepart.YyaaErspe = oRepartImmSet.Erspe;
			// 	oDefaultRepart.YyaaLetja = oRepartImmSet.Letja;
			// 	oDefaultRepart.YyaaLetpe = oRepartImmSet.Letpe;
			// } else {
			// 	if (oDefaultHeader.YaaNbreMese === "001") {
			// 		oDefaultRepart.YyaaErspe = oRepartImmSet.Erspe;
			// 		oDefaultRepart.YyaaLetpe = oRepartImmSet.Letpe;
			// 	} else {
			// 		// Récup sur YAA_MESE_REPART avec la RG YAA_NBRE_MESE
			// 	}
			// }
			// +1 sur le max
			var sYaaRgNew = new Number(1);
			Object.keys(oModel.getData()).forEach(function(i) {
				if (sYaaRgNew <= new Number(oModel.getData()[i].YaaRg)) {
					sYaaRgNew = new Number(oModel.getData()[i].YaaRg);
					sYaaRgNew++;
				}
			}, this);

			oDefaultRepart.YaaRg = ("000" + sYaaRgNew).slice(-3);

			oActions.push(oDefaultRepart);

			oModel.setData(oActions);

		},

		onDeleteMeseItems: function(e) {
			var oTab = this.byId(sap.ui.core.Fragment.createId("RegRepartFragment", "table-Reg-Repart"));
			var aItems = oTab.getSelectedItems();
			var oModel = this.getView().getModel("MeseItemsJSON");
			var oModelData = oModel.getProperty("/");

			for (var i = aItems.length - 1; i >= 0; i--) {
				var sPath = aItems[0].oBindingContexts.MeseItemsJSON.sPath;
				var idx = parseInt(sPath.substring(sPath.lastIndexOf('/') + 1));
				oModelData.splice(idx, 1);
			}

			this.resetFiesNbr();

			oModel.setProperty("/MeseItems", oModelData);
			oModel.refresh(true);
			oTab.removeSelections(true);
		},
		resetFiesNbr: function() {
			var aRgReparts = this.getView().getModel("MeseItemsJSON").getData();
			var that = this;
			aRgReparts.forEach((oRgRepart, index) => {
				oRgRepart.YaaRg = that.alphaConversion(index + 1, '0', 3);
			});
		},
		alphaConversion: function(sValue, sCharToUse, iLength) {
			var sNewValue = "";
			var sAlpha = "";
			var iLengthToComplete = iLength - parseInt(sValue.toString().length);
			for (var i = 0; i < iLengthToComplete; i++) {
				sAlpha += sCharToUse.toString();
			}
			sNewValue = sAlpha + sValue.toString();
			return sNewValue;
		},
		addMessage: function(sMsg, sTarget, sType) {
			/*	sap.ui.getCore().getMessageManager().addMessages(new sap.ui.core.message.Message({
					message: this.getModel("i18n").getResourceBundle().getText(sMsg) ? this.getModel("i18n").getResourceBundle().getText(sMsg) : sMsg,
					description: this.getModel("i18n").getResourceBundle().getText(sMsg) ? this.getModel("i18n").getResourceBundle().getText(sMsg) : sMsg,
					additionalText: "",
					processor: this.getModel("MeseItemsJSON"),
					persistent: true,
					type: sType ? sType : sap.ui.core.MessageType.Error,
					target: sTarget ? sTarget : "/#TRANSIENT"
				}));*/
		},

		ctrlRegRepartEmpty: function() {
			/*	if (this.getModel("MeseItemsJSON").getProperty("/").length === 0) {
					this.addMessage("msgCtrlEmpty");
					var error = true;
				}
				return error;*/
		},

		ctrlRegRepartLibelle: function(sValue, idx, addMsg) {
			//RG21.12.6
			if (sValue === "") var error = true;
			if (addMsg && error) this.addMessage("msgCtrl012", "/" + idx + "/YyaaTextFies");
			return error;
		},

		ctrlRegRepartCumul: function(addMsg) {
			//RG21.12.8
			var oModel = this.getModel("MeseItemsJSON");
			var oModelData = oModel.getProperty("/");
			var nCumul = new Number(0);

			for (var i = 0; i < oModelData.length; i++) {
				nCumul = nCumul + new Number(oModelData[i].YyaaPourcent);
			}

			if (nCumul > 100) {
				var error = true;
			} else {
				error = false;
			}
			if (addMsg && error) {
				for (i = 0; i < oModelData.length; i++) {
					this.addMessage("msgCtrl013", "/MeseItemsJSON/" + i + "/YyaaPourcent");
				}
			}
			return error;
		},

		ctrlRegRepartFinPer: function(addMsg) {
			//RG12.12.20
			var oModel = this.getModel("MeseItemsJSON");
			var oModelData = oModel.getProperty("/");
			for (var i = 0; i < oModelData.length; i++) {
				var j = i + 1;
				if (j < oModelData.length && oModelData[i].YyaaErspe !== oModelData[j].YyaaErspe) var error = true;
			}
			if (addMsg && error) {
				for (i = 0; i < oModelData.length; i++) {
					this.addMessage("msgCtrl029", "/MeseItemsJSON/" + i + "/YyaaErspe");
				}
			}
			return error;
		},

		ctrlRegRepartUQteFull: function(addMsg) {
			//RG12.12.11
			var oModel = this.getModel("MeseItemsJSON");
			var oModelData = oModel.getProperty("/");
			for (var i = 0; i < oModelData.length; i++) {
				var j = i + 1;
				if (j < oModelData.length && oModelData[i].yyps_u_qte !== oModelData[j].yyps_u_qte) var error = true;
			}
			if (addMsg && error) {
				for (i = 0; i < oModelData.length; i++) {
					this.addMessage("msgCtrl016", "/MeseItemsJSON/" + i + "/yyps_u_qte");
				}
			}
			return error;
		},

		ctrlRegRepartFinEx: function(addMsg) {
			//RG12.12.20
			var oModel = this.getModel("MeseItemsJSON");
			var oModelData = oModel.getProperty("/");
			for (var i = 0; i < oModelData.length; i++) {
				var j = i + 1;
				if (j < oModelData.length && oModelData[i].YyaaLetpe !== oModelData[j].YyaaLetpe) var error = true;
			}
			if (addMsg && error) {
				for (i = 0; i < oModelData.length; i++) {
					this.addMessage("msgCtrl029", "/MeseItemsJSON/" + i + "/YyaaLetpe");
				}
			}
			return error;
		},

		ctrlRegRepartCoeff: function(sValue, idx, addMsg) {
			//RG21.12.6
			if (sValue === "") var error = true;
			if (addMsg && error) this.addMessage("msgCtrlMandatory", "/MeseItemsJSON/" + idx + "/YyaaCoeff");
			return error;
		},

		ctrlRegRepartMontant: function(sValue, idx, addMsg) {
			//RG21.12.10
			if (sValue === "0.000") var error = true;
			if (addMsg && error) this.addMessage("msgCtrl014", "/MeseItemsJSON/" + idx + "/YyaaMtt");
			return error;
		},

		ctrlRegRepartDevise: function(sValue, idx, addMsg) {
			//RG21.12.10
			if (sValue === "") var error = true;
			if (addMsg && error) this.addMessage("msgCtrlMandatory", "/MeseItemsJSON/" + idx + "/YyaaDev");
			return error;
		},

		ctrlRegRepartQte: function(sValue, idx, addMsg) {
			//RG21.12.11
			if (sValue === "0") var error = true;
			if (addMsg && error) this.addMessage("msgCtrl015", "/MeseItemsJSON/" + idx + "/YyaaQte");
			return error;
		},

		ctrlRegRepartUQte: function(sValue, idx, addMsg) {
			//RG21.12.11 faire la partie YPS_ETI- YYPS_U_QTE
			if (sValue === "") var error = true;
			if (addMsg && error) this.addMessage("msgCtrlMandatory", "/MeseItemsJSON/" + idx + "/YyaaUQte");
			return error;
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {

		},

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},

		/**
		 * Event handler for navigating back.
		 * We navigate back in the browser historz
		 * @public
		 */
		onNavBack: function() {
			history.go(-1);
		},

		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var aTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					aTableSearchState = [new Filter("Pbukr", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(aTableSearchState);
			}

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function() {
			var oTable = this.byId("table");
			oTable.getBinding("items").refresh();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("Pbukr")
			});
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {sap.ui.model.Filter[]} aTableSearchState An array of filters for the search
		 * @private
		 */
		_applySearch: function(aTableSearchState) {
			var oTable = this.byId("table"),
				oViewModel = this.getModel("worklistView");
			oTable.getBinding("items").filter(aTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		},

		OnRegRepartPress: function() {

			//           window.location.replace("https://finance-sbx.enedis.fr:44300/sap/bc/ui5_ui5/sap/z_regrepart/index.html?sap-client=200&sap-ui-language=FR&sap-ui-xx-devmode=true");
			var sRef =
				"https://finance-sbx.enedis.fr:44300/sap/bc/ui5_ui5/sap/z_regrepart/index.html?sap-client=200&sap-ui-language=FR&sap-ui-xx-devmode=true";
			sap.m.URLHelper.redirect(sRef, true);

		},

		onAddButtonRegRepartPress: function() {
			if (!this._viewRegRepartAddDialog) {
				var fragmentName = "enedis.fiaa.mese.MESE_NEW.view.fragments.ViewRegRepartAddDialog";
				this._viewRegRepartAddDialog = this._instantiateFragment(fragmentName);
				this.getView().addDependent(this._viewRegRepartAddDialog, this);
			}
			this._viewRegRepartAddDialog.open();

		},

		closeDialog: function(oEvent) {

			oEvent.getSource().getParent().close();

		},

		OnSaveButtonPress: function() {
			// Lancer les contrôles front

			// var oModel = this.getModel("MeseItemsJSON");
			// var oModelData = oModel.getProperty("/");
			// var oEtiSet = this.getView().getModel("EtiSet").getData();
			// var oMeseCreationModel = this.getView().getModel("meseCreationModel").getData();

			// sap.ui.getCore().getMessageManager().removeAllMessages();
			// if (!this.ctrlRegRepartEmpty()) {
			//           for (var i = 0; i < oModelData.length; i++) {
			//                         this.ctrlRegRepartLibelle(oModelData[i].YyaaTextFies, i, true);
			//                         this.ctrlRegRepartCoeff(oModelData[i].YyaaCoeff, i, true);
			//                         this.ctrlRegRepartMontant(oModelData[i].YyaaMtt, i, true);
			//                         this.ctrlRegRepartDevise(oModelData[i].YyaaDev, i, true);
			//                         if (oEtiSet.YypsUQte) this.ctrlRegRepartQte(oModelData[i].YyaaQte, i, true);
			//                         if (oEtiSet.YypsUQte) this.ctrlRegRepartUQte(oModelData[i].YyaaUQte, i, true);
			//           }
			//           if (oMeseCreationModel.YyaatypeRepart === "2") this.ctrlRegRepartCumul(true);
			//           this.ctrlRegRepartFinPer(true);
			//           this.ctrlRegRepartFinEx(true);
			//           if (oEtiSet.YypsUQte) this.ctrlRegRepartUQteFull(true);
			// }

			var that = this;

			var dialog = new sap.m.Dialog({
				title: "Confirmation Sauvegarde Mese",
				type: "Message",
				content: new sap.m.Text({
					text: "Voulez vous sauvegarder la nouvelle Mese?"
				}),
				beginButton: new sap.m.Button({
					text: "Oui",
					press: function() {
						dialog.close();
						that.saveMeseData("save");

					}
				}),
				endButton: new sap.m.Button({
					text: "Non",
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();

		},

		saveMeseData: function(param) {

			var oModel = this.getView().getModel();
			var oBusyDialog = new sap.m.BusyDialog();
			oBusyDialog.open();
			var objectParameter = this.prepareMeseData();
			if (param === "Draft") {
				this.getOwnerComponent().getModel("createMeseModel").setProperty("/IsActive", "");
			} else {
				this.getOwnerComponent().getModel("createMeseModel").setProperty("/IsActive", "");
			}
			var that = this;
			oModel.create("/MeseHeaderSet", objectParameter, {
				success: function(data, resp) {
					if (resp.headers["sap-message"]) {
						var oResponse = $.parseJSON(resp.headers["sap-message"]);

						if (oResponse.severity !== "success") {
							var message = $.parseJSON(resp.headers["sap-message"]).message;
							sap.m.MessageBox.warning(message);
							oBusyDialog.close();
							return;
						}
					}

					if (param === "Draft") {
						sap.m.MessageToast.show("Version préliminaire sauvegardée!");
						this.getView().byId("draftTextid").setVisible(true);
					} else {
						sap.m.MessageToast.show("mese sauvegardée avec succès!")
						this.getView().byId("draftTextid").setVisible(false);
					}
					//that.getView().byId("IdSaveButton").setEnebaled(true);
					oBusyDialog.close();

				}.bind(this),
				error: function(data, resp) {
					oBusyDialog.close();
				}
			});

		},

		saveMese: function() {

			// A étudier pourquoi
			var oModel = this.getView().getModel();
			//var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/YSFI1_MESE_HANAIS_SRV/");
			var oBusyDialog = new sap.m.BusyDialog();
			oBusyDialog.open();
			var objectParameter = this.prepareMeseData();
			var that = this;
			oModel.create("/MeseHeaderSet", objectParameter, {
				success: function(data, resp) {
					if (resp.headers["sap-message"]) {
						var oResponse = $.parseJSON(resp.headers["sap-message"]);

						if (oResponse.severity !== "success") {
							var message = $.parseJSON(resp.headers["sap-message"]).message;
							sap.m.MessageBox.warning(message);
							oBusyDialog.close();
							return;
						}
					}

					sap.m.MessageToast.show("mese sauvegardée avec succès!");
					//that.getView().byId("IdSaveButton").setEnebaled(true);
					oBusyDialog.close();

				}.bind(this),
				error: function(data, resp) {
					oBusyDialog.close();
				}
			});

		},

		prepareMeseData: function() {
			var mese = {};
			var meseNav = this.getView().getModel("createMeseModel").getData();
			var meseNavNav = this.getView().getModel("createMeseNavModel").getData();

			//mese.Aedat = meseNav.Aedat
			if (meseNav.Aenam) {
				mese.Aenam = meseNav.Aenam
			}
			if (meseNav.Draftuuid) {
				mese.Draftuuid = meseNav.Draftuuid
			}
			//mese.Erdat = meseNav.Erdat
			if (meseNav.Ernam) {
				mese.Ernam = meseNav.Ernam
			}
			if (meseNav.Fkstl) {
				mese.Fkstl = meseNav.Fkstl
			}
			if (meseNav.IsActive) {
				mese.IsActive = meseNav.IsActive
			}
			if (meseNav.Objnr) {
				mese.Objnr = meseNav.Objnr
			}
			if (meseNav.Pbukr) {
				mese.Pbukr = meseNav.Pbukr
			}
			if (meseNav.Pgsbr) {
				mese.Pgsbr = meseNav.Pgsbr
			}
			if (meseNav.Pkokr) {
				mese.Pkokr = meseNav.Pkokr
			}
			if (meseNav.Posid) {
				mese.Posid = meseNav.Posid
			}
			if (meseNav.Prctr) {
				mese.Prctr = meseNav.Prctr
			}
			if (meseNav.PsPspnr) {
				mese.PsPspnr = meseNav.PsPspnr
			}
			if (meseNav.Post1) {
				mese.Post1 = meseNav.YyaaTextF

			}
			//mese.Timestmp = meseNav.Timestmp
			if (meseNav.Tplnr) {
				mese.Tplnr = meseNav.Tplnr
			}
			if (meseNav.YaaNbreMese) {
				mese.YaaNbreMese = meseNav.YaaNbreMese
			}
			//mese.YaaProcessP = meseNav.YaaProcessP
			if (meseNav.YaamotifRet) {
				mese.YaamotifRet = meseNav.YaamotifRet
			}
			if (meseNav.YaanbrjRet) {
				mese.YaanbrjRet = meseNav.YaanbrjRet
			}
			if (meseNav.YpsetiMuli) {
				mese.YpsetiMuli = meseNav.YpsetiMuli
			}
			if (meseNav.YyaaTextF) {
				mese.YyaaTextF = meseNav.YyaaTextF
			}

			mese.YyaaTextI = meseNavNav.Post1

			if (meseNav.YyaadateMese) {
				mese.YyaadateMese = meseNav.YyaadateMese
			}
			if (meseNav.YyaaetiF) {
				mese.YyaaetiF = meseNav.YyaaetiF
			}
			if (meseNavNav.Yypseti) {
				mese.YyaaetiI = meseNav.YyaaetiI
			}
			if (meseNav.YyaainsF) {
				mese.YyaainsF = meseNav.YyaainsF
			}
			if (meseNavNav.Yypsins) {
				mese.YyaainsI = meseNav.YyaainsI
			}
			if (meseNav.YyaastatMese) {
				mese.YyaastatMese = meseNav.YyaastatMese
			}
			if (meseNav.YyaatypeRepart) {
				mese.YyaatypeRepart = meseNav.YyaatypeRepart
			}
			if (meseNav.Yypsajout) {
				mese.Yypsajout = meseNav.Yypsajout
			}
			if (meseNav.YypscodeMoa) {
				mese.YypscodeMoa = meseNav.YypscodeMoa
			}
			if (meseNav.YypsregJurid) {
				mese.YypsregJurid = meseNav.YypsregJurid
			}
			if (meseNav.YypsrenouvRet) {
				mese.YypsrenouvRet = meseNav.YypsrenouvRet
			}
			if (meseNav.YypsueI) {
				mese.YypsueI = meseNav.YypsueI
			}

			mese.MeseHeaderToItems = [];
			//mese.MeseHeaderToItems = this.prepareMeseItemsData();

			return mese;

		},

		prepareMeseItemsData: function() {

			var items = this.getView().getModel("MeseItemsJSON").getProperty("/");
			return items;

			/*
			var items = [];
			var item = {};
                                          
			item.Pkokr = "EH00";
			item.PsPspnr = "00000003";
			item.Pbukr = "D001";
			item.YaaNbreMese = "001";
			item.YaaRg = "001";
			// Ernam
			// Erdat
			// Aenam
			// Aedat
			// Timestmp
			// YyaaTextFies
			// YyaaPourcent
			// YyaaCoeff
			// YyaaMtt
			// YyaaDev
			// YyaaQte
			// YyaaUQte
			// YyaaErsja
			// YyaaErspe
			// YyaaLetja
			// YyaaLetpe
			// Yyaaanlue
			// YyaafiesAjout
			// YyaafiesRattP
			// YyaafiesRattS
			// Yyaains
			// YyaaueF
			// Yyaaimat
			// Yyaainvent
			// Yyaaplan
			// Yyaaparcelle
			// YaadurA
			// YaadurM
			// Yaabelnr0lP
			// Yaabelnr0lI
			// Yaagjahr0lP
			// Yaagjahr0lI
			// Yaabelnr2lP
			// Yaabelnr2lI
			// Yaagjahr2lP
			// Yaagjahr2lI
			// Yaaanln1
			// Yaaanln2

			items.push(item);

			return items;
			*/
		},

		onCompanyChange: function() {

		},
		onPrepareMeseData: function(data) {

			this.getView().getModel("createMeseModel");
			if (data.IsActive !== "X") {
				this.getView().byId("draftTextid").setVisible(true);
			}
			this.getView().getModel("createMeseModel").setProperty("/Draftuuid", data.Draftuuid);
			this.getView().getModel("createMeseModel").setProperty("/IsActive", data.IsActive);
			this.getView().getModel("createMeseModel").setProperty("/Pbukr", data.Pbukr);
			this.getView().getModel("createMeseModel").setProperty("/Pgsbr", data.Pgsbr);
			this.getView().getModel("createMeseModel").setProperty("/Pkokr", data.Pkokr);
			this.getView().getModel("createMeseModel").setProperty("/Posid", data.Posid);
			this.getView().getModel("createMeseModel").setProperty("/Post1", data.Post1);
			this.getView().getModel("createMeseModel").setProperty("/Prctr", data.Prctr);
			this.getView().getModel("createMeseModel").setProperty("/YypscodeMoa", data.YypscodeMoa);
			this.getView().getModel("createMeseModel").setProperty("/YypsrenouvRet", data.YypsrenouvRet);
			this.getView().getModel("createMeseModel").setProperty("/Yypsajout", data.Yypsajout);
			this.getView().getModel("createMeseModel").setProperty("/PsPspnr", data.PsPspnr);
			this.getView().getModel("createMeseModel").setProperty("/YaaNbreMese", data.YaaNbreMese);
			this.getView().getModel("createMeseModel").setProperty("/Fkstl", data.Fkstl);
			this.getView().getModel("createMeseModel").setProperty("/Erdat", data.Erdat)
			this.getView().getModel("createMeseModel").setProperty("/YypsregJurid", data.YypsregJurid);
			this.getView().getModel("createMeseModel").setProperty("/Aenam", data.Aenam);
			this.getView().getModel("createMeseModel").setProperty("/Objnr", data.Objnr);
			this.getView().getModel("createMeseModel").setProperty("/YyaadateMese", data.YyaadateMese);
			this.getView().getModel("createMeseModel").setProperty("/YyaainsI", data.YyaainsI);
			this.getView().getModel("createMeseModel").setProperty("/YyaainsF", data.YyaainsF);
			this.getView().getModel("createMeseModel").setProperty("/YyaaetiF", data.YyaaetiF);
			this.getView().getModel("createMeseModel").setProperty("/YyaaetiI", data.YyaaetiI);
			this.getView().getModel("createMeseModel").setProperty("/YyaaTextF", data.YyaaTextF);
			this.getView().getModel("createMeseModel").setProperty("/YyaaTextI", data.YyaaTextI);
			this.getView().getModel("createMeseModel").setProperty("/YyaastatMese", data.YyaastatMese);
			this.getView().getModel("createMeseModel").setProperty("/YyaastatMese", data.YyaastatMese);
			this.getView().getModel("createMeseModel").setProperty("/YyaatypeRepart", "1");
			this.getView().getModel("createMeseModel").setProperty("/YaanbrjRet", 0);

			//this.getView().getModel("createMeseModel").refresh(true);

			/*	
				mese.Aedat = data.Aedat;
				mese.Aenam = data.Aenam;
				mese.Erdat = data.Erdat;
				mese.Ernam = data.Ernam;
				mese.Fkstl = data.Fkstl;
				mese.Objnr = data.Objnr;
				mese.Tplnr = data.Tplnr;
				mese.YaaProcessP = data.YaaProcessP;
				mese.YaamotifRet = data.YaamotifRet;
				mese.YaanbrjRet = data.YaanbrjRet;
				mese.YpsetiMuli = data.YpsetiMuli;
				mese.YyaaTextF = data.YyaaTextF;
				mese.YyaaetiI = data.YyaaetiI;
				mese.YyaainsF = data.YyaainsF;
				mese.YyaastatMese = data.YyaastatMese;
				mese.YyaatypeRepart = data.YyaatypeRepart;
				mese.Yypsajout = data.Yypsajout;
				mese.YypscodeMoa = data.YypscodeMoa;
				mese.YypsregJurid = data.YypsregJurid;
				mese.YypsrenouvRet = data.YypsrenouvRet;
				mese.YypsueI = data.YypsueI;*/

		},
		onConfirmDraft: function(oEvent) {
			this.saveMeseData("Draft");
		},

		onAfterRendering: function(oEvent) {
			this.attachSaveDraftOnEnter("otpId");

		},
		attachSaveDraftOnEnter: function(sInputId) {
			var that = this;
			var oInput = this.getView().byId(sInputId);
			oInput.onsapenter = ((oEvent) => {
				that.saveMeseData("Draft");
			});
		},

		onEtiValueHelpRequest: function() {
			var oEtiVhModel = this.getView().getModel("EtiVh");
			if (!this._viewEtiValueHelpDialog) {
				var fragmentName = "enedis.fiaa.mese.MESE_NEW.view.fragments.ValueHelpEti";
				this._viewEtiValueHelpDialog = new sap.ui.xmlfragment(fragmentName, this);
				this._viewEtiValueHelpDialog.setModel(oEtiVhModel, "EtiVh");
				this.getView().addDependent(this._viewEtiValueHelpDialog, this);
			}
			this._viewEtiValueHelpDialog.open();
		},
		getVh: function(sVhEntitySet) {
			var oMainService = this.getOwnerComponent().getModel();
			return new Promise(function(resolve, reject) {
				oMainService.read(sVhEntitySet, {
					success: function(oSuccess, oResp) {
						resolve(oSuccess.results);
					},
					error: oResp => reject(oResp)
				});
			});
		},

		onCommuneValueHelpRequest: function() {
			var oCommuneVhModel = this.getView().getModel("communeVh");
			if (!this._viewCommuneValueHelpDialog) {
				var fragmentName = "enedis.fiaa.mese.MESE_NEW.view.fragments.ValueHelpCommune";
				this._viewCommuneValueHelpDialog = new sap.ui.xmlfragment(fragmentName, this);
				this._viewCommuneValueHelpDialog.setModel(oCommuneVhModel, "communeVh");
				this.getView().addDependent(this._viewCommuneValueHelpDialog, this);
			}
			this._viewCommuneValueHelpDialog.open();
		},

		//on close  ValueHelp Dialog
		closeDialog: function(oEvent) {
			oEvent.getSource().getParent().close();
		},

		handleConfirmVHEti: function(oEvent) {
			var sEtiDesc, sCodeEti;
			sCodeEti = sap.ui.getCore().byId("listEti").getSelectedItem().getCells()[0].getTitle();
			sEtiDesc = sap.ui.getCore().byId("listEti").getSelectedItem().getCells()[1].getText();
			this.getView().getModel("createMeseModel").setProperty("/YyaaetiF", sCodeEti);

			this.updateRgRepartEti(sCodeEti);
			this.onHeaderDataChange();
			this._viewEtiValueHelpDialog.close();
		},
		updateRgRepartEti: function(sCodeEti) {
			var oRgPartData = this.getOwnerComponent().getModel("MeseItemsJSON").getData();
			if (oRgPartData.length > 0) {
				oRgPartData.forEach(oRgRepart => {
					oRgRepart.YyaaetiF = sCodeEti;
				});
				this.getOwnerComponent().getModel("MeseItemsJSON").refresh(true);
			}
		},
		handleConfirmVHCommune: function(oEvent) {
			var sCodeCommune = sap.ui.getCore().byId("listCommune").getSelectedItem().getCells()[0].getTitle();
			this.getView().getModel("createMeseModel").setProperty("/YyaainsF", sCodeCommune);
			this.updateRgRepartCommune(sCodeCommune);
			this.onHeaderDataChange();
			this._viewCommuneValueHelpDialog.close();
		},
		updateRgRepartCommune: function(sCodeCommune) {
			var oRgPartData = this.getOwnerComponent().getModel("MeseItemsJSON").getData();
			if (oRgPartData.length > 0) {
				oRgPartData.forEach(oRgRepart => {
					oRgRepart.YyaainsF = sCodeCommune;
				});
				this.getOwnerComponent().getModel("MeseItemsJSON").refresh(true);
			}
		},
		onTableReerender: function(oEvent) {
			var test = oEvent;
		},
		onInitiliseMeseRepartParam: function(Pkokr, WBSElement) {

			this.getView().getModel().callFunction("/getDevise", {
				method: "GET",
				urlParameters: {
					"pkokr": Pkokr
				},
				success: function(oSuccess, oResp) {
					//	oDefaultRepart.YyaaDev = oSuccess.getDevise.Return;
					this.getOwnerComponent().getModel("MeseRepartParam").setProperty("/YDevise", oSuccess.getDevise.Return);

				}.bind(this),
				error: function(oError, oResp) {}
			});
			this.getView().getModel().callFunction("/initPeriodeValidite", {
				method: "GET",
				urlParameters: {
					"objnr": WBSElement,
				},
				success: function(oSuccess, oResp) {

					this.getOwnerComponent().getModel("MeseRepartParam").setProperty("/Yperiode_val_deb", oSuccess.initPeriodeValidite.PeriodeValDeb);
					this.getOwnerComponent().getModel("MeseRepartParam").setProperty("/Yperiode_val_fin", oSuccess.initPeriodeValidite.PeriodeValFin);
					this.getOwnerComponent().getModel("MeseRepartParam").setProperty("/Yexercice_val_deb", oSuccess.initPeriodeValidite.ExerciceValDeb);
					this.getOwnerComponent().getModel("MeseRepartParam").setProperty("/Yexercice_val_fin", oSuccess.initPeriodeValidite.ExerciceValFin);

				}.bind(this),
				error: function(oError, oResp) {

				}
			});
		},
		checkMeseDate: function(oSelectedDate) {
			var sCurrentYear = new Date().getFullYear(),
				sCurrentMonth = new Date().getMonth() + 1,
				sCurrentDate = new Date().getDate();
			var oDateDuJour = sCurrentDate + "/" + sCurrentMonth + "/" + sCurrentYear;

			var oSelectedDate = new Date(oSelectedDate.substring(6) + "-" + oSelectedDate.substring(3, 5) + "-" + oSelectedDate.substring(0, 2));
			var oNewDateDuJour = new Date(sCurrentYear + "-" + sCurrentMonth + "-" + sCurrentDate);

			if (oSelectedDate < oNewDateDuJour) {
				this.getMsgFromBD("dateMeseAnterieur").then(sMsg => {
					sap.m.MessageBox.warning(sMsg);
				})
				this.setNbrJoursRetard(oSelectedDate);

			} else {
				this.getView().getModel("createMeseModel").setProperty("/YaanbrjRet", "");
				this.getView().getModel("createMeseModel").setProperty("/YaamotifRet", "");
				this.getView().byId("motifRetInputId").setEnabled(false);
				this.getView().byId("MotifRetardColumn").setVisible(false);
				this.getView().byId("NbrJrsRetardColumn").setVisible(false);
			}
		},
		setNbrJoursRetard: function(oSelectedDate) {

			var diff = {} // Initialisation du retour
			var tmp = oSelectedDate - new Date();

			tmp = Math.floor(tmp / 1000); // Nombre de secondes entre les 2 dates
			diff.sec = tmp % 60; // Extraction du nombre de secondes

			tmp = Math.floor((tmp - diff.sec) / 60); // Nombre de minutes (partie entière)
			diff.min = tmp % 60; // Extraction du nombre de minutes

			tmp = Math.floor((tmp - diff.min) / 60); // Nombre d'heures (entières)
			diff.hour = tmp % 24; // Extraction du nombre d'heures

			tmp = Math.floor((tmp - diff.hour) / 24); // Nombre de jours restants
			diff.day = tmp;

			this.getView().getModel("createMeseModel").setProperty("/YaanbrjRet", Math.abs(diff.day));
			this.getView().byId("motifRetInputId").setEnabled(true);
			this.getView().byId("MotifRetardColumn").setVisible(true);
			this.getView().byId("NbrJrsRetardColumn").setVisible(true);

			return diff;

		},
		getMsgFromBD: function(sMsgCode) {
			var that = this;
			this.getView().setBusy(true);
			var oMainService = this.getOwnerComponent().getModel();
			return new Promise(function(resolve, reject) {
				oMainService.callFunction("/getMsgFromBD", {
					method: "GET",
					urlParameters: {
						"msgCode": sMsgCode
					},
					success: function(oSuccess, oResp) {
						that.getView().setBusy(false);
						resolve(oSuccess.getMsgFromBD.Message);
					},
					error: oResp => {
						that.getView().setBusy(false);
						reject(oResp);
					}
				});
			});
		},
		setMaxMeseDate: function() {
			var sCurrentYear = new Date().getFullYear();
			var oMaxDate = new Date(sCurrentYear, 11, 31);
			this.getView().byId("dateMeseInputId").setMaxDate(oMaxDate);
		},
		onHeaderDataChange: function(oEvent) {
			var oHeaderData = this.getView().getModel("createMeseModel");
			/*We are going to check every field every time the user changes the data*/
			//Société
			var bSociete = oHeaderData.getProperty("/Pbukr") && oHeaderData.getProperty("/Pbukr") !== "";
			//OTP
			var bOTP = oHeaderData.getProperty("/Posid") && oHeaderData.getProperty("/Posid") !== "";
			//Libelle
			var bLibelle = oHeaderData.getProperty("/YyaaTextF") && oHeaderData.getProperty("/YyaaTextF") !== "";
			//Date MESEYyaadateMese
			var bDateMese = oHeaderData.getProperty("/YyaadateMese") && oHeaderData.getProperty("/YyaadateMese") !== "";
			//ETI
			var bETI = oHeaderData.getProperty("/YyaaetiF") && oHeaderData.getProperty("/YyaaetiF") !== "";
			//Commune
			var bCommune = oHeaderData.getProperty("/YyaainsF") && oHeaderData.getProperty("/YyaainsF") !== "";
			//NbrJourRetard
			var bNbrJour = true;
			if (this.getView().byId("NbrJrsRetardColumn").getVisible()) {
				bNbrJour = oHeaderData.getProperty("/YaanbrjRet") && oHeaderData.getProperty("/YaanbrjRet") !== "";
			}
			//Motif Retard
			var bMotifRetard = true;
			if (this.getView().byId("MotifRetardColumn").getVisible()) {
				bMotifRetard = oHeaderData.getProperty("/YaamotifRet") && oHeaderData.getProperty("/YaamotifRet") !== "";
			}
			//Régime Juridique
			var bJuridique = oHeaderData.getProperty("/YypsregJurid") && oHeaderData.getProperty("/YypsregJurid") !== "";
			//Centre de profit
			var bCntrProfit = oHeaderData.getProperty("/Prctr") && oHeaderData.getProperty("/Prctr") !== "";
			//Domaine d'activite
			var bActDom = oHeaderData.getProperty("/Pgsbr") && oHeaderData.getProperty("/Pgsbr") !== "";
			//Code Moa
			var bCodeMoa = oHeaderData.getProperty("/YypscodeMoa") && oHeaderData.getProperty("/YypscodeMoa") !== "";

			if (bSociete && bOTP && bLibelle && bDateMese && bETI && bCommune && bNbrJour && bMotifRetard && bJuridique && bCntrProfit &&
				bActDom && bCodeMoa) {
				this.getView().byId("WizardStep1").setValidated(true);
			} else {
				this.getView().byId("WizardStep1").setValidated(false);
			}
		},
		handleSearchEti: function() {
			var aFilters = [],
				sEtiCode = sap.ui.getCore().byId("inputEti").getValue();
			var sEtiLiblle = sap.ui.getCore().byId("inputEti_Text").getValue();
			if (sEtiCode !== "") {
				aFilters.push(new sap.ui.model.Filter("Eti", sap.ui.model.FilterOperator.StartsWith, sEtiCode));
			}
			if (sEtiLiblle !== "") {
				aFilters.push(new sap.ui.model.Filter("Libelle", sap.ui.model.FilterOperator.StartsWith, sEtiLiblle));
			}
			if (aFilters !== []) {
				sap.ui.getCore().byId("listEti").getBinding("items").filter(aFilters);
			}
		},
		handleSearchCommune : function(){
			var aFilters = [],
				sCommune = sap.ui.getCore().byId("inputCommune").getValue();
			var sCommuneLiblle = sap.ui.getCore().byId("inputCommune_Text").getValue();
			if (sCommune !== "") {
				aFilters.push(new sap.ui.model.Filter("Commune", sap.ui.model.FilterOperator.StartsWith, sCommune));
			}
			if (sCommuneLiblle !== "") {
				aFilters.push(new sap.ui.model.Filter("Libelle", sap.ui.model.FilterOperator.StartsWith, sCommuneLiblle));
			}
			if (aFilters !== []) {
				sap.ui.getCore().byId("listCommune").getBinding("items").filter(aFilters);
			}
		}

	});
});