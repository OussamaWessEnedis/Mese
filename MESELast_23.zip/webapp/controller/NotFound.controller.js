sap.ui.define([
		"enedis/fiaa/mese/MESE_NEW/controller/BaseController"
	], function (BaseController) {
		"use strict";

		return BaseController.extend("enedis.fiaa.mese.MESE_NEW.controller.NotFound", {

			/**
			 * Navigates to the worklist when the link is pressed
			 * @public
			 */
			onLinkPressed : function () {
				this.getRouter().navTo("worklist");
			}

		});

	}
);