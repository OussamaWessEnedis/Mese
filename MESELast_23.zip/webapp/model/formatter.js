sap.ui.define([], function() {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},

		isEditable: function(sStatut, bEditable) {
			var STATUT_VALEUR_INTIALE = "MES01";
			var STATUT_SAISIE_ICOMPLETE = "MES02";
			var STATUT_SAISIE_NON_CONTROLEE = "MES03";
			var STATUT_ERREUR_BLOQUANTE = "MES04";
			var STATUT_VALIDATION_ATTENTE = "MES05";
			return (
				(sStatut === STATUT_VALEUR_INTIALE ||
					sStatut === STATUT_SAISIE_ICOMPLETE ||
					sStatut === STATUT_SAISIE_NON_CONTROLEE ||
					sStatut === STATUT_ERREUR_BLOQUANTE ||
					sStatut === STATUT_VALIDATION_ATTENTE) &&
				bEditable
			);
		},
		step1Validation: function(sValue1, sValue2, sValue3) {
			return sValue1 === "None" && sValue2 === "None" && sValue3 === "None";
		}
	};
});