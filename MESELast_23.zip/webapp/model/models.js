sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function(JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function() {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},

		//create the notification creation model&nbsp;
		createMeseModel: function() {
			var data = {
				"Aedat": "",
				"Aenam": "",
				"Draftuuid": "",
				"Erdat": "",
				"Ernam": "",
				"Fkstl": "",
				"IsActive": "",
				"Objnr": "",
				"Pbukr": "",
				"Pgsbr": "",
				"Pkokr": "",
				"Posid": "",
				"Prctr": "",
				"PsPspnr": "",
				"Timestmp": "",
				"Tplnr": "",
				"YaaNbreMese": "",
				"YaaProcessP": "",
				"YaamotifRet": "",
				"YaanbrjRet": "",
				"YpsetiMuli": "",
				"YyaaTextF": "",
				"YyaaTextI": "",
				"YyaadateMese": "",
				"YyaaetiF": "",
				"YyaaetiI": "",
				"YyaainsF": "",
				"YyaainsI": "",
				"YyaastatMese": "",
				"YyaatypeRepart": "",
				"Yypsajout": "",
				"YypscodeMoa": "",
				"YypsregJurid": "",
				"YypsrenouvRet": "",
				"YypsueI": "",
				"MeseHeaderToItems": []
			};

			var oModel = new JSONModel(data);
			return oModel;
		},

		createMeseNavModel: function() {
			var data = {
				"Pbukr": "",
				"Pkokr": "",
				"Post1": "",
				"PsPspnr": "",
				"YaaNbreMese": "",
				"Draftuuid": "",
				"Posid": "",
				"IsActive": "",
				"Pgsbr": "",
				"Prctr": "",
				"Yypsins": "",
				"Yypseti": "",
				"YypscodeMoa": "",
				"Yypsajout": "",
				"YypsregJurid": "",
				"YyaadateMese": ""

			};
			var oModel = new JSONModel(data);
			return oModel;
		},

		createMeseItemsModel: function() {
			var data = {
				"Pkokr": "00000000",
				"PsPspnr": "00000000",
				"Draftuuid": "00000000",
				"Pbukr": "",
				"IsActive": "",
				"YaaNbreMese": "",
				"YaaRg": "001",
				"Ernam": "",
				"Erdat": "00000000",
				"Aenam": "",
				"Aedat": "00000000",
				"Timestmp": " 0",
				"YyaaTextFies": "",
				"YyaaPourcent": "0",
				"YyaaCoeff": "1",
				"YyaaMtt": "0.000",
				"YyaaDev": "",
				"YyaaQte": "0",
				"YyaaUQte": "",
				"YyaaErsja": "000",
				"YyaaErspe": "0000",
				"YyaaLetja": "000",
				"YyaaLetpe": "0000",
				"Yyaaanlue": "",
				"Yypsajout": "",
				"YyaafiesAjout": "",
				"YyaafiesRattP": "",
				"YyaafiesRattS": "",
				"Yyaains": "",
				"YyaaueF": "",
				"Yyaaimat": "",
				"Yyaainvent": "",
				"Yyaaplan": "",
				"Yyaaparcelle": "",
				"YaadurA": "000",
				"YaadurM": "",
				"Yaabelnr0lP": "",
				"Yaabelnr0lI": "",
				"Yaagjahr0lP": "0000",
				"Yaagjahr0lI": "0000",
				"Yaabelnr2lP": "",
				"Yaabelnr2lI": "",
				"Yaagjahr2lP": "0000",
				"Yaagjahr2lI": "0000",
				"Yaaanln1": "",
				"Yaaanln2": ""
			};
			var oModel = new JSONModel(data);
			return oModel;
		},

		createRepartImmModel: function() {
			var data = {
				"Objnr": "",
				"Lednr": "",
				"Ldgrp": "",
				"Bureg": "",
				"Lfdnr": "",
				"Ersja": "000",
				"Erspe": "0000",
				"Letja": "000",
				"Letpe": "0000"
			};
			var oModel = new JSONModel(data);
			return oModel;
		},

		fieldsStateGeneralDataModel: function(oData, oController) {
			var sValueStateMotRetard, sValueStateMotRetardTxt;
			if (
				oController.getView().byId("nbJoursRetInputId").getValue() >
				oData.SeuilJourMin
			) {
				sValueStateMotRetard = "Error";
				sValueStateMotRetardTxt = "Champ obligatoire";
			} else {
				sValueStateMotRetard = "None";
			}
			var oValueState = {
				dateMeseInputId: {
					valueState: "Error",
					valueStateText: "Champ obligatoire",
				},
				etiInputId: {
					backEditable: oData.IsEtiEditable ? true : false,
					editable: false,
				},
				inseeInputId: {
					editable: oData.IsCommEditable ? true : false,
				},
				motifRetInputId: {
					seuilJoursMin: oData.SeuilJourMin,
					valueState: sValueStateMotRetard,
					valueStateText: sValueStateMotRetardTxt,
				},
				typeRepartComboId: {
					valueState: "None",
					valueStateText: "",
				},
			};
			return new JSONModel(oValueState);
		},

		typeRepartComboIdModel: function() {
			var oTypeRepartition = {
				types: [{
					key: "1",
					text: "1: pas de répartition"
				}, {
					key: "2",
					text: "2: répartition en %"
				}, {
					key: "3",
					text: "3: répartition par coefficient d'équivalence"
				}, {
					key: "4",
					text: "4: répartition par montants"
				}, {
					key: "5",
					text: "5: répartition par quantité"
				}, ],
			};
			return new JSONModel(oTypeRepartition);
		},

		errorMsgPopupModel: function() {
			var errorMsgPopupModel = {
				text: ""
			};
			return new JSONModel(errorMsgPopupModel);
		},

	};

});