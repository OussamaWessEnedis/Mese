/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"enedis/fiaa/mese/MESE_NEW/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"enedis/fiaa/mese/MESE_NEW/test/integration/pages/Worklist",
	"enedis/fiaa/mese/MESE_NEW/test/integration/pages/Object",
	"enedis/fiaa/mese/MESE_NEW/test/integration/pages/NotFound",
	"enedis/fiaa/mese/MESE_NEW/test/integration/pages/Browser",
	"enedis/fiaa/mese/MESE_NEW/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "enedis.fiaa.mese.MESE_NEW.view."
	});

	sap.ui.require([
		"enedis/fiaa/mese/MESE_NEW/test/integration/WorklistJourney",
		"enedis/fiaa/mese/MESE_NEW/test/integration/ObjectJourney",
		"enedis/fiaa/mese/MESE_NEW/test/integration/NavigationJourney",
		"enedis/fiaa/mese/MESE_NEW/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});