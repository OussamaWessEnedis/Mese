/* global document */
sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"enedis/fiaa/mese/MESE_NEW/model/models",
	"enedis/fiaa/mese/MESE_NEW/controller/ErrorHandler"
], function(UIComponent, Device, models, ErrorHandler) {
	"use strict";

	return UIComponent.extend("enedis.fiaa.mese.MESE_NEW.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * In this function, the device models are set and the router is initialized.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// initialize the error handler with the component
			this._oErrorHandler = new ErrorHandler(this);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");

			//set the Mese creation model
			this.setModel(models.createMeseModel(), "createMeseModel");

			//set the Mese creation model
			this.setModel(models.createMeseItemsModel(), "meseItemsCreationModel");

			//set the Mese Navigation creation model
			//this.setModel(models.createMeseNavModel(), "meseNavCreationModel");
			this.setModel(models.createMeseNavModel(), "createMeseNavModel");

			//set the Type de répartition model
			this.setModel(models.typeRepartComboIdModel(), "typeRepartComboIdModel");

			//set the Type de répartition model
			this.setModel(models.errorMsgPopupModel(), "errorMsgPopupModel");
			
			// this.getModel().attachBatchRequestSent(this._onBatchRequestSent, this);
			// this.getModel().attachBatchRequestCompleted(this._onBatchRequestCompleted, this);

			// A changer par Jean-Marie selon son model, c'était pour tester
			//var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YSFI1_MESE_HANAIS_SRV/");
			// var filters = new Array();
			// var oNavMese = this.getModel("createMeseNavModel").getData();
			// filters.push(new sap.ui.model.Filter("Pkokr", sap.ui.model.FilterOperator.EQ, oNavMese.Pkokr)); //""));
			// filters.push(new sap.ui.model.Filter("PsPspnr", sap.ui.model.FilterOperator.EQ, oNavMese.PsPspnr)); //"00000000"));
			// filters.push(new sap.ui.model.Filter("Draftuuid", sap.ui.model.FilterOperator.EQ, oNavMese.Draftuuid)); //"00000000"));
			// filters.push(new sap.ui.model.Filter("Pbukr", sap.ui.model.FilterOperator.EQ, oNavMese.Pbukr)); //""));
			// filters.push(new sap.ui.model.Filter("IsActive", sap.ui.model.FilterOperator.EQ, oNavMese.IsActive)); //""));
			// filters.push(new sap.ui.model.Filter("YaaNbreMese", sap.ui.model.FilterOperator.EQ, oNavMese.YaaNbreMese)); //"000"));

		/*	this.getModel().read("/MeseItemsSet", {
				filters: filters,
				// A mettre dans une fonction
				success: function(e) {
					//Transformer l'oData en JSON simple, sans les attributs d'objet si odata direct et sans uri etc si passage du result
					Object.keys(e.results).forEach(function(i) {
						delete e.results[i].__metadata;
					}, this);
					var oMeseItemsSetJSONModel = new sap.ui.model.json.JSONModel();
					oMeseItemsSetJSONModel.setData(e.results);
					this.setModel(oMeseItemsSetJSONModel, "MeseItemsJSON");
				}.bind(this),
				error: function(e) {}
			}, this);*/

			// var sEti = this.getModel("meseCreationModel").getData().YyaaetiF || this.getModel("createMeseNavModel").getData().YyaaetiI;
			// var sPath = "/EtiSet(Ypseti='" + sEti + "')";
			// this.getModel().read(sPath, {
			// 	success: function(e) {
			// 		//Transformer l'oData en JSON simple, sans les attributs d'objet si odata direct et sans uri etc si passage du result
			// 		delete e.__metadata;
			// 		var oEtiSetJSONModel = new sap.ui.model.json.JSONModel();
			// 		oEtiSetJSONModel.setData(e);
			// 		this.setModel(oEtiSetJSONModel, "EtiSet");
			// 	}.bind(this),
			// 	error: function(e) {}
			// }, this);

			// var sPathCobrb = "/RepartImmSet(Objnr='" + this.getModel("createMeseNavModel").getData().Objnr + "')";
			// this.getModel().read(sPathCobrb, {
			// 	success: function(e) {
			// 		//Transformer l'oData en JSON simple, sans les attributs d'objet si odata direct et sans uri etc si passage du result
			// 		delete e.__metadata;
			// 		var oEtiSetJSONModel = new sap.ui.model.json.JSONModel();
			// 		oEtiSetJSONModel.setData(e);
			// 		this.setModel(oEtiSetJSONModel, "RepartImmSet");
			// 	}.bind(this),
			// 	error: function(e) {
			// 		var oEtiSetJSONModel = new sap.ui.model.json.JSONModel();
			// 		oEtiSetJSONModel.setData(models.createRepartImmModel().getData());
			// 		this.setModel(oEtiSetJSONModel, "RepartImmSet");
			// 	}.bind(this)
			// }, this);

			//this.getModel().attachBatchRequestSent(this._onBatchRequestSent, this);
			//this.getModel().attachBatchRequestCompleted(this._onBatchRequestCompleted, this);

			// create the views based on the url/hash
			this.getRouter().initialize();
		},

		/**
		 * The component is destroyed by UI5 automatically.
		 * In this method, the ErrorHandler is destroyed.
		 * @public
		 * @override
		 */
		destroy: function() {
			this._oErrorHandler.destroy();
			// call the base component's destroy function
			UIComponent.prototype.destroy.apply(this, arguments);
		},

		/**
		 * This method can be called to determine whether the sapUiSizeCompact or sapUiSizeCozy
		 * design mode class should be set, which influences the size appearance of some controls.
		 * @public
		 * @return {string} css class, either 'sapUiSizeCompact' or 'sapUiSizeCozy' - or an empty string if no css class should be set
		 */
		getContentDensityClass: function() {
			if (this._sContentDensityClass === undefined) {
				// check whether FLP has already set the content density class; do nothing in this case
				if (jQuery(document.body).hasClass("sapUiSizeCozy") || jQuery(document.body).hasClass("sapUiSizeCompact")) {
					this._sContentDensityClass = "";
				} else if (!Device.support.touch) { // apply "compact" mode if touch is not supported
					this._sContentDensityClass = "sapUiSizeCompact";
				} else {
					// "cozy" in case of touch support; default for most sap.m controls, but needed for desktop-first controls like sap.ui.table.Table
					this._sContentDensityClass = "sapUiSizeCozy";
				}
			}
			return this._sContentDensityClass;
		}

	});

});